-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th9 07, 2024 lúc 09:51 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `chatai`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `account`
--

CREATE TABLE `account` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `account`
--

INSERT INTO `account` (`id`, `fullname`, `email`, `password`) VALUES
(1, 'Nguyễn Văn Hoan', 'a5k47hoan@gmail.com', '123'),
(2, 'Nguyễn Văn A', '1@gmail.com', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chats`
--

CREATE TABLE `chats` (
  `id` int(10) UNSIGNED NOT NULL,
  `idtitle` int(11) NOT NULL,
  `content` text NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chats`
--

INSERT INTO `chats` (`id`, `idtitle`, `content`, `type`) VALUES
(69, 23, 'Bạn có thể cho tôi biết thời tiết ở Thủ Ðô Hà Nội bây giờ không?', 1),
(70, 23, 'Dự báo thời tiết tỉnh Thủ Ðô Hà Nội: Nhiệt độ: 25.03°C, Độ ẩm: 100%, Mưa: Không', 0),
(71, 23, 'Xin chào', 1),
(72, 23, 'Xin chào! Rất vui được gặp bạn. Bạn có muốn tôi giúp gì không? \n', 0),
(73, 23, 'Không nhé', 1),
(74, 23, 'Bạn có thể cho mình biết \"không\" là \"không\" gì không? \n\nĐể tôi có thể giúp bạn tốt hơn, bạn có thể chia sẻ thêm thông tin hoặc ngữ cảnh về điều bạn đang muốn nói. \n', 0),
(75, 23, 'thời tiết ha noi', 1),
(76, 23, 'Dự báo thời tiết tỉnh Shahrīār Kandeh: Nhiệt độ: 23.96°C, Độ ẩm: 83%, Mưa: Không', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `messengers`
--

CREATE TABLE `messengers` (
  `id` int(11) NOT NULL,
  `mess` text DEFAULT NULL,
  `users` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `messengers`
--

INSERT INTO `messengers` (`id`, `mess`, `users`, `time`) VALUES
(110, 'Viết 1 đoạn code python', 1, '2024-06-26 12:06:04'),
(111, 'Viết 1 đoạn code python', 1, '2024-06-26 12:06:07'),
(112, 'Viết 1 đoạn code python', 1, '2024-06-26 12:06:09'),
(113, '```python\ndef tính_tổng(a, b):\n  \"\"\"Hàm tính tổng của hai số.\"\"\"\n  return a + b\n\n# Nhập hai số từ người dùng\na = int(input(\"Nhập số thứ nhất: \"))\nb = int(input(\"Nhập số thứ hai: \"))\n\n# Gọi hàm tính tổng và in kết quả\ntổng = tính_tổng(a, b)\nprint(f\"Tổng của {a} và {b} là: {tổng}\")\n```\n\n**Code này làm gì?**\n\n1. **Xác định hàm `tính_tổng(a, b)`:**\n   - Hàm này nhận hai tham số `a` và `b`.\n   - Hàm tính tổng của `a` và `b` và trả về kết quả.\n\n2. **Nhập dữ liệu từ người dùng:**\n   - Code sử dụng `input()` để yêu cầu người dùng nhập hai số.\n   - Các giá trị nhập vào được chuyển đổi sang kiểu số nguyên bằng `int()`.\n\n3. **Gọi hàm `tính_tổng()`:**\n   - Code gọi hàm `tính_tổng()` với hai số đã nhập làm tham số.\n   - Kết quả trả về từ hàm được lưu vào biến `tổng`.\n\n4. **In kết quả:**\n   - Code in ra kết quả tổng của hai số.\n\n**Cách chạy code:**\n\n1. Lưu code vào một file với phần mở rộng `.py` (ví dụ: `tinh_tong.py`).\n2. Mở terminal hoặc command prompt.\n3. Chạy lệnh `python tinh_tong.py`.\n4. Code sẽ yêu cầu bạn nhập hai số. Nhập hai số và nhấn Enter.\n5. Code sẽ in ra tổng của hai số.\n', 2, '2024-06-26 12:06:10'),
(114, '```python\ndef tinh_tong(a, b):\n  \"\"\"Hàm tính tổng của hai số.\"\"\"\n  return a + b\n\n# Nhập hai số từ người dùng\na = float(input(\"Nhập số thứ nhất: \"))\nb = float(input(\"Nhập số thứ hai: \"))\n\n# Gọi hàm tính tổng và in kết quả\ntong = tinh_tong(a, b)\nprint(f\"Tổng của {a} và {b} là: {tong}\")\n```\n\n**Giải thích:**\n\n* Đoạn code này định nghĩa một hàm `tinh_tong()` để tính tổng của hai số.\n* Hàm nhận hai tham số là `a` và `b`, và trả về tổng của chúng.\n* Code sau đó yêu cầu người dùng nhập hai số, lưu vào biến `a` và `b`.\n* Cuối cùng, code gọi hàm `tinh_tong()` với `a` và `b` làm đối số, lưu kết quả vào biến `tong` và in ra màn hình.\n\n**Cách chạy code:**\n\n1. Lưu code vào một file với đuôi `.py` (ví dụ: `tong.py`).\n2. Mở terminal hoặc command prompt.\n3. Chuyển đến thư mục chứa file code.\n4. Chạy lệnh `python tong.py`.\n\nCode sẽ yêu cầu bạn nhập hai số, sau đó in ra kết quả tổng của hai số đó.\n', 2, '2024-06-26 12:06:11'),
(115, '```python\ndef tính_tổng_các_số_chẵn(danh_sách):\n  \"\"\"Hàm tính tổng các số chẵn trong một danh sách.\n\n  Args:\n    danh_sách: Danh sách các số nguyên.\n\n  Returns:\n    Tổng các số chẵn trong danh sách.\n  \"\"\"\n\n  tổng = 0\n  for số in danh_sách:\n    if số % 2 == 0:\n      tổng += số\n  return tổng\n\n# Ví dụ sử dụng\ndanh_sách_số = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]\ntổng_các_số_chẵn = tính_tổng_các_số_chẵn(danh_sách_số)\nprint(f\"Tổng các số chẵn trong danh sách là: {tổng_các_số_chẵn}\")\n```\n\nĐoạn code này định nghĩa một hàm `tính_tổng_các_số_chẵn` nhận một danh sách các số nguyên làm đầu vào. Hàm này sẽ duyệt qua từng phần tử trong danh sách và kiểm tra xem phần tử đó có chia hết cho 2 hay không. Nếu phần tử chia hết cho 2 (là số chẵn), hàm sẽ cộng giá trị của phần tử vào một biến `tổng`. Cuối cùng, hàm trả về giá trị của biến `tổng`.\n\nTrong ví dụ sử dụng, chúng ta tạo một danh sách các số nguyên và gọi hàm `tính_tổng_các_số_chẵn` với danh sách này làm đối số. Hàm trả về tổng các số chẵn trong danh sách và kết quả được in ra màn hình.\n', 2, '2024-06-26 12:06:14'),
(116, 'xin chào', 1, '2024-06-26 12:22:40'),
(117, 'Xin chào! Rất vui được gặp bạn. Bạn có muốn nói chuyện về gì không? \n', 2, '2024-06-26 12:22:41'),
(118, 'xin chào', 1, '2024-06-26 12:22:47'),
(119, 'Xin chào! Rất vui được gặp bạn. Bạn có muốn tôi giúp gì không? \n', 2, '2024-06-26 12:22:48'),
(120, 'xin chào', 1, '2024-06-26 12:22:52'),
(121, 'xin chào', 1, '2024-06-26 12:22:52'),
(122, 'xin chào', 1, '2024-06-26 12:22:52'),
(123, 'xin chào', 1, '2024-06-26 12:22:52'),
(124, 'Xin chào! Rất vui được gặp bạn. Bạn có muốn tôi giúp gì không? \n', 2, '2024-06-26 12:22:53'),
(125, 'Xin chào! Rất vui được gặp bạn! Bạn có muốn tôi giúp gì không? \n', 2, '2024-06-26 12:22:54'),
(126, 'Xin chào! Rất vui được gặp bạn! Bạn có muốn nói gì không? \n', 2, '2024-06-26 12:22:54'),
(127, 'Xin chào! Rất vui được gặp bạn. Bạn muốn tôi giúp gì hôm nay? \n', 2, '2024-06-26 12:22:54'),
(130, 'xin chào', 1, '2024-06-26 12:31:42'),
(131, 'Xin chào! Rất vui được gặp bạn! Bạn có muốn tôi giúp gì không? \n', 2, '2024-06-26 12:31:44'),
(133, 'Lâm tô ăn cứt', 1, '2024-08-28 09:02:46'),
(134, 'Lâm tô ăn cứt', 1, '2024-08-28 09:02:48'),
(135, 'Tôi xin lỗi, nhưng tôi không hiểu câu hỏi của bạn. Bạn có thể vui lòng diễn đạt lại câu hỏi của bạn?', 2, '2024-08-28 09:02:51'),
(136, 'Tôi xin lỗi, nhưng tôi không hiểu câu hỏi của bạn. Bạn có thể diễn đạt lại không? \n', 2, '2024-08-28 09:02:51'),
(140, 'Thời tiết hôm nay', 1, '2024-09-07 13:29:33'),
(141, 'Tôi không thể cung cấp thông tin thời tiết thực thời. \n\nĐể kiểm tra thời tiết hôm nay, bạn có thể:\n\n* **Sử dụng một trang web thời tiết như AccuWeather, Weather.com hoặc Google Weather.**\n* **Kiểm tra ứng dụng thời tiết trên điện thoại thông minh của bạn.**\n* **Hỏi trợ lý ảo như Siri, Alexa hoặc Google Assistant.**\n\nHãy cho tôi biết bạn muốn kiểm tra thời tiết ở đâu, tôi có thể giúp bạn tìm kiếm thông tin đó! \n', 2, '2024-09-07 13:29:36'),
(142, 'Thời tiết Hà Nội hôm nay', 1, '2024-09-07 13:29:53'),
(143, 'Tôi không thể cung cấp thông tin thời tiết trực tiếp. \n\nĐể biết thời tiết ở Hà Nội hôm nay, bạn có thể thử:\n\n* **Kiểm tra các ứng dụng dự báo thời tiết:** Có rất nhiều ứng dụng thời tiết miễn phí như AccuWeather, WeatherBug, The Weather Channel.\n* **Truy cập trang web dự báo thời tiết:** Các trang web dự báo thời tiết uy tín như Accuweather.com, Weather.com, hay trang web của cơ quan khí tượng địa phương.\n* **Hỏi trợ lý ảo:** Bạn có thể hỏi Siri, Alexa, hay Google Assistant về thời tiết ở Hà Nội.\n\nChúc bạn một ngày tốt đẹp! \n', 2, '2024-09-07 13:29:56'),
(144, 'các trợ lý ảo có thể lấy được thời tiết Hà Nội hôm nay', 1, '2024-09-07 13:30:58'),
(145, 'Tôi không thể cung cấp thông tin thời tiết trực tiếp. \n\nĐể biết thời tiết Hà Nội hôm nay, bạn có thể thử:\n\n* **Kiểm tra trang web dự báo thời tiết uy tín:** Ví dụ như AccuWeather, Weather.com, VnExpress,...\n* **Sử dụng trợ lý ảo trên điện thoại của bạn:** Google Assistant, Siri, Alexa đều có thể cung cấp thông tin thời tiết.\n* **Sử dụng ứng dụng dự báo thời tiết:** Có rất nhiều ứng dụng dự báo thời tiết miễn phí và dễ sử dụng trên điện thoại.\n\nChúc bạn tìm được thông tin cần thiết! 😊\n', 2, '2024-09-07 13:31:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `title`
--

CREATE TABLE `title` (
  `id` int(10) UNSIGNED NOT NULL,
  `idaccount` int(11) NOT NULL,
  `NameTitle` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `title`
--

INSERT INTO `title` (`id`, `idaccount`, `NameTitle`) VALUES
(23, 1, 'Thời tiết Hà Nội hiện tại? \n');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `messengers`
--
ALTER TABLE `messengers`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `title`
--
ALTER TABLE `title`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `account`
--
ALTER TABLE `account`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT cho bảng `messengers`
--
ALTER TABLE `messengers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT cho bảng `title`
--
ALTER TABLE `title`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

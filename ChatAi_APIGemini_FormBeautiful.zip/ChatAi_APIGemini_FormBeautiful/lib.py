
import mysql.connector
import google.generativeai as genai
import json
import spacy
import requests


def connection_mysql():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='chatai'
    ) 
    return connection

def get_account_by_username(username, password):
    connection = connection_mysql()
    cursor = connection.cursor()
    # Truy vấn SQL
    query = "SELECT * FROM account WHERE email = %s and password = %s"
    cursor.execute(query, (username, password))
    # Lấy tất cả kết quả
    result = cursor.fetchall()
    # Đóng kết nối
    cursor.close()
    connection.close()   
    return result

def CallApiGe(prompt):
    genai.configure(api_key="AIzaSyAPvjxOI6TXYzG5otTSEK79dWrQJAU4ZQU")
    model = genai.GenerativeModel(model_name="gemini-1.5-flash")
    response = model.generate_content([prompt])
    response = response.text.replace('**','')
    return response.replace('##','')

def Title_Summary(prompt):
    genai.configure(api_key="AIzaSyAPvjxOI6TXYzG5otTSEK79dWrQJAU4ZQU")
    model = genai.GenerativeModel(model_name="gemini-1.5-flash")
    response = model.generate_content(["Đặt chỉ 1 tiêu đề ngắn gọn cho nội dung sau: ", prompt])
    response = response.text.replace('**','')
    return response.replace('##','')

# Đọc file JSON với mã hóa UTF-8
with open('D:\Code\Project_Completed\ChatAi_APIGemini_FormBeautiful\city_list.json', 'r', encoding='utf-8') as file:
    data = json.load(file)

# Load mô hình spaCy
nlp = spacy.load('en_core_web_sm')

# Hàm tìm kiếm tỉnh và hiển thị thông tin tương ứng
def search_location(query):
    query_doc = nlp(query)
    
    for location in data:
        if query.lower() in location['name'].lower():
            return location['name']
    
    return None  # Trả về None nếu không tìm thấy tỉnh

def CallApiWeather(CITY):
    API_KEY = 'aa41b38f8663d74a7ebbba1e68dc7274'
    URL = f'http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric'
    try:
        response = requests.get(URL)
        data = response.json()
        if data['cod'] == 200:
            temperature = data['main']['temp']
            humidity = data['main']['humidity']
            weather_description = data['weather'][0]['description']
            # Kiểm tra xem có mưa hay không
            Rain = 'rain' in weather_description.lower()
            return temperature, humidity, Rain, CITY  # Nhiệt độ, độ ẩm, dự báo
        else:
            return "Không lấy được dữ liệu thời tiết."
    except Exception as e:
        return f"Error: {e}"
    
def return_WeatherData(prompt):
    
    city_name = search_location(prompt)
    if city_name:
        result = CallApiWeather(city_name)
        if isinstance(result, tuple):  # Nếu kết quả là một tuple (nghĩa là có dữ liệu thời tiết)
            temperature, humidity, Rain, city_name = result
            strData = f"Dự báo thời tiết tỉnh {city_name}: Nhiệt độ: {temperature}°C, Độ ẩm: {humidity}%, Mưa: {'Có' if Rain else 'Không'}"
            return strData
        else: return 'Không lấy được dữ liệu thời tiết.'
    else: return 'Tỉnh không được tìm thấy.'

def Tim_KiemTinh(strpromt):
    for location in data:
        if location['name'].lower() in strpromt.lower():
            return location['name']
    return None  # Trả về None nếu không tìm thấy tỉnh
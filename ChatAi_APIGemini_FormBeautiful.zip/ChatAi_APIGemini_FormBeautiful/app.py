from flask import Flask, render_template, request, redirect, url_for, session
import os
import google.generativeai as genai
import mysql.connector
import datetime
import lib
import json

genai.configure(api_key="AIzaSyAPvjxOI6TXYzG5otTSEK79dWrQJAU4ZQU")
model = genai.GenerativeModel(model_name="gemini-1.5-flash")

app = Flask(__name__)
app.secret_key = '123456789'  # Cần để sử dụng session

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect(url_for('index'))  # Chuyển hướng tới trang index nếu đã đăng nhập
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        account = lib.get_account_by_username(username, password)  # Truy vấn tài khoản
        if account and account[0][3] == password:  # Kiểm tra tài khoản và mật khẩu
            session['username'] = username
            session['idaccount'] = account[0][0]  # Lưu thông tin người dùng vào session
            return redirect(url_for('index'))  # Chuyển hướng tới trang index
        else:
            return render_template('login.html', error="Tên đăng nhập hoặc mật khẩu không đúng!")  # Báo lỗi
    
    return render_template('login.html')  # Hiển thị trang login

# Đăng xuất
@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('idaccount', None)
    return redirect(url_for('login'))  # Chuyển hướng về trang login

# New chat
@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    connection = lib.connection_mysql()
    cursor = connection.cursor()
    
    # Truy vấn tiêu đề dựa vào tài khoản đăng nhập
    title_query = "SELECT * FROM title WHERE idaccount = %s ORDER BY id ASC"
    cursor.execute(title_query, (session['idaccount'],))
    title = cursor.fetchall()  # Lấy tất cả kết quả từ truy vấn title

    # Đóng kết nối
    cursor.close()
    connection.close()
    
    return render_template('index.html', title=title)

@app.route('/newchat', methods=['POST'])
def newchat():
    try:
        connection = lib.connection_mysql()
        cursor = connection.cursor()

        inputpromt = request.form['messageInput']
        Title_Summary = lib.Title_Summary(inputpromt)

        # Thực hiện chèn dữ liệu vào bảng title
        title_query = "INSERT INTO title (idaccount, NameTitle) VALUES (%s, %s)"
        cursor.execute(title_query, (session['idaccount'], Title_Summary))
        connection.commit()

        # Lấy id của title vừa chèn
        id_title_query = "SELECT id FROM title WHERE NameTitle = %s AND idaccount = %s"
        cursor.execute(id_title_query, (Title_Summary, session['idaccount']))
        result = cursor.fetchone()

        if not result:
            return '''
                <script>
                    alert("Lỗi truy vấn dữ liệu");
                    window.location.href = "/";
                </script>
            '''
        
        idtitle = result[0]

        # Thực hiện chèn dữ liệu vào bảng chats
        query = "INSERT INTO chats (idtitle, content, type) VALUES (%s, %s, %s)"
        cursor.execute(query, (idtitle, inputpromt, 1))
        if 'thời tiết' in inputpromt.lower():
            city = lib.Tim_KiemTinh(inputpromt)
            cursor.execute(query, (idtitle, lib.return_WeatherData(city), 0))
        else:cursor.execute(query, (idtitle, lib.CallApiGe(inputpromt), 0))
        connection.commit()

    except Exception as e:
        # Xử lý lỗi và đảm bảo kết nối được đóng
        print(f"Lỗi: {e}")
        return '''
            <script>
                alert("Đã xảy ra lỗi. Vui lòng thử lại.");
                window.location.href = "/";
            </script>
        '''

    finally:
        cursor.close()
        connection.close()

    return redirect(f'/detail/?id={idtitle}')

@app.route('/detail/', methods=['GET'])
def detail():
    id_Title = request.args.get('id', default=None, type=int)
    
    if 'username' not in session:
        return redirect(url_for('login'))

    try:
        connection = lib.connection_mysql()
        cursor = connection.cursor()

        # Truy vấn tiêu đề dựa vào tài khoản đăng nhập
        title_query = "SELECT * FROM title WHERE idaccount = %s ORDER BY id ASC"
        cursor.execute(title_query, (session['idaccount'],))
        title = cursor.fetchall()  # Lấy tất cả kết quả từ truy vấn title

        # Truy vấn tin nhắn dựa vào idtitle
        if id_Title is not None:
            messenger_query = "SELECT * FROM chats WHERE idtitle = %s"
            cursor.execute(messenger_query, (id_Title,))
            messenger = cursor.fetchall()  # Lấy tất cả tin nhắn
        else:
            messenger = []

    except Exception as e:
        print(f"Lỗi: {e}")
        title = []
        messenger = []

    finally:
        cursor.close()
        connection.close()

    return render_template('index.html', title=title, messenger=messenger, id_Title=id_Title)

@app.route('/sendchat', methods=['POST'])
def sendchat():
    connection = lib.connection_mysql()
    cursor = connection.cursor()
    id_Title = request.form['id_Title']
    promt = request.form['messageInput']
    query = "INSERT INTO chats (idtitle, content, type) VALUES (%s, %s, %s)"
    cursor.execute(query, (id_Title, promt, 1))
    if 'thời tiết' in promt.lower():
        city = lib.Tim_KiemTinh(promt)
        cursor.execute(query, (id_Title, lib.return_WeatherData(city), 0))
    else: cursor.execute(query, (id_Title, lib.CallApiGe(promt), 0))
    connection.commit()
    cursor.close()
    connection.close()
    return redirect(f'/detail/?id={id_Title}')

@app.route('/refresh_All')
def refresh_All():
    connection = lib.connection_mysql()
    cursor = connection.cursor()
    try:
        cursor.execute('DELETE FROM chats')
        cursor.execute('DELETE FROM title')
        connection.commit()
    except Exception as e:
        connection.rollback()  # Quay lại nếu có lỗi
        print(f"Error: {e}")
    finally:
        cursor.close()
        connection.close()
    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)

import subprocess
import sys

import mysql.connector
import google.generativeai as genai
import json
import spacy
import requests
from flask import Flask, render_template, request, redirect, url_for, session
import os
import google.generativeai as genai
import mysql.connector
import datetime
import lib
import json

modules = [
    'mysql-connector-python',
    'google-generativeai',
    'spacy',
    'requests',
    'Flask'
]

def install_package(package_name):
    try:
        # Cài đặt mô-đun bằng pip
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        print(f"Module {package_name} has been installed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to install module {package_name}. Error: {e}")

for module_package in modules:
    try: 
        install_package(module_package)
    except Exception as e:
        print(f"Error: {e}")